﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T4___DS_1102223_E1
{
    internal class Program
    {
        static void Main(string[] args)
        {
           int valores = 0;
            Console.WriteLine("Ingrese velocidad inicial");
            double vo = ObtenerNum();
            Console.WriteLine("Ingrese velocidad final");
            double vf = ObtenerNum();
            Console.WriteLine("Ingrese aceleración");
            double a = ObtenerNum();
            Console.WriteLine("Ingrese tiempo");
            double t = ObtenerNum(); 

            if(!double.IsNaN(vo) ) 
            {
                valores++;
            }if(!double.IsNaN(vf) )
            {
                valores++;
            }if(!double.IsNaN(a) ) 
            {
                valores++;
            } if(!double.IsNaN(t) )
            {
                valores++;
            }

            if(valores!=3)
            {
                Console.WriteLine("Error, ingrese 3 valores");
            }else
            {
                if(double.IsNaN(vf))
                {
                    vf = vo + a * t;
                    Console.WriteLine("La velocidad final es de: " + vf+"m/s");
                }else if (double.IsNaN(vo)) { 
                    vo=vf-a * t;
                    Console.WriteLine("La velocidad inicial es de: "+vo+"m/s");
                }else if (double.IsNaN(a))
                {
                    a = (vf - vo) / t;
                    Console.WriteLine("La aceleración es: " +a+"m/s^2");
                }else if (double.IsNaN(t))
                {
                    t=(vf - vo) / a;
                    Console.WriteLine("El tiempo es de: " + t + "s"); 
                }
            }
            Console.ReadKey();
        }

        public static double ObtenerNum()
        {
            double numero;
            if(!double.TryParse(Console.ReadLine(), out numero)) {
                Console.WriteLine("Entrada no válida");
                return double.NaN;
            }else { return numero; }
        }
    }
}
