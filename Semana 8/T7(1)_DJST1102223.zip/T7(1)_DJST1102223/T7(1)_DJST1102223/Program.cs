﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T7_1__DJST1102223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" No. 01");
            double serie1 = 0; double serie2 = 0;
            Console.WriteLine("Ingrese un número entero positivo");
            int num = int.Parse(Console.ReadLine());
            if (num < 0)
            {
                Console.WriteLine("Valor erróneo");
            }
            else
            {
                for (int o = 1; o <= num; o++)
                {
                    serie1 =+ 1 / o;
                    Console.WriteLine(serie1);
                }
            }
            Console.WriteLine("Serie No. 02");
            if (num < 0)
            {
                Console.WriteLine("Valor erróneo");
            }
            else
            {
                Console.WriteLine("Los resultados de 1 partido 2 elevado cada número hasta el número ingresado"
                    + " serían:");
                for (int o = 1; o <= num; o++)
                {
                    serie2 = 1 / 2 ^ o;
                    Console.WriteLine(serie2);
                }
            }
            Console.WriteLine("Serie No. 03");
            Console.WriteLine("Ingrese un número entero x");
            int x = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese un número entero a");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese un número entero n");
            int n = int.Parse(Console.ReadLine());
            int resultado = 0;

            for (int k = 0; k <= n; k++)
            {

                resultado = (x ^ k) * (a ^ (n - k));
                Console.WriteLine(resultado);
            }

            Console.ReadKey();
        }
    }
}
