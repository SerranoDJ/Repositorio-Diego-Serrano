﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_3_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Km = 0, velocidad1 = 0, velocidad2=0, velocidad3=0, tiempo = 0; string nombre1 = "", nombre2="", nombre3="";
            Console.WriteLine("Ingrese el número de kilómetros de la carrera");
            Km= Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese nombre del competidor 1");
            nombre1 = Console.ReadLine();
            Console.WriteLine("Ingrese velocidad del competidor 1");
            velocidad1=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese nombre del competidor 2");
            nombre2= Console.ReadLine();
            Console.WriteLine("Ingrese velocidad del competidor 2");
            velocidad2=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Ingrese nombre del competidor 3");
            nombre3 = Console.ReadLine();
            Console.WriteLine("Ingrese velocidad del competidor 3");
            velocidad3 = Convert.ToInt32(Console.ReadLine());

            if(velocidad1>velocidad2 && velocidad1 > velocidad3)
            {
                tiempo = Km / velocidad1;
                Console.WriteLine("El ganador es: "+nombre1+" y su tiempo será de: " +tiempo+"h");
            }else if(velocidad2>velocidad1 && velocidad2>velocidad3){
                tiempo= Km / velocidad2;
                Console.WriteLine("El ganador es: "+nombre2+" y su tiempo será de: "+tiempo+"h");
            }else if (velocidad3>velocidad2 && velocidad3>velocidad1){
                tiempo=Km / velocidad3;
                Console.WriteLine("El ganador es: " + nombre3 + " y su tiempo será de: " + tiempo + "h");
            }

            Console.ReadKey();
        }
    }
}
