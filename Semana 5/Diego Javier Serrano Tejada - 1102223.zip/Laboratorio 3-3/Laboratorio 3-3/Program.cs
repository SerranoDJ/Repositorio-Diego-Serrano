﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_3_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n=0, noRes=1; string respuesta = "";
            while (noRes<= 5)
            {
                Console.WriteLine("Ingrese Respuesta");
                respuesta = Console.ReadLine();
                if (respuesta == "Si")
                {
                    n = n + 5;
                    noRes = noRes+1;
                }
                else if (respuesta == "No")
                {
                    n = n - 1;
                    noRes = noRes+1;
                }
                else if (respuesta == "")
                {
                    n = n;
                    noRes = noRes+1;
                }
            }
            Console.WriteLine("El punteo es: " + n);
            Console.ReadKey();
        }
    }
}
