﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_3_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valorO = 100000, depreciaC = 50000, depreAnual=0, ciclosU = 6;
            
            depreAnual = (valorO - depreciaC) * (2 / ciclosU);
            Console.WriteLine("La depreciación del vehículo será de: ");
            Console.WriteLine(depreAnual);

            Console.ReadKey();
        }
    }
}
