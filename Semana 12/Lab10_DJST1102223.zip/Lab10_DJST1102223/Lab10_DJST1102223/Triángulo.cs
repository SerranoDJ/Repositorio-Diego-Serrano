﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_DJST1102223
{
    internal class Triángulo
    {
        private double catetoA;
        private double anguloOpA;
        private double catetoB;
        private double hipo;
        private double angulob;

        public Triángulo(double catetoA, double anguloOA) 
        {
        this.catetoA = catetoA;
        this.anguloOpA = anguloOA;
        }

        public void anguloOpB(double anguloOB)
        {
            angulob = anguloOB;
            anguloOB = 180-anguloOpA + 90;      
        }
        public void catetob()
        {
            double cateB = (catetoA * Math.Sin(anguloOpA))/Math.Sin((anguloOpA + 90) - 180);
            catetoB = cateB;
        }
        public double ObtenerCatB() 
        {
            return catetoB;
        }
        public double ObtenerAnB() 
        {
            return angulob;
        }
    }
}
