﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_DJST1102223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese Cateto A y ángulo opuesto a A");
            Triángulo triangulo = new Triángulo(Convert.ToDouble(Console.ReadLine()), Convert.ToDouble(Console.ReadLine()));
            Console.WriteLine(triangulo.ObtenerAnB());
            Console.ReadKey();
        }
    }
}
