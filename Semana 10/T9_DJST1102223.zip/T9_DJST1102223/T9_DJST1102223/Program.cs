﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_DJST1102223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Motocicleta objMotocicleta = new Motocicleta();
            objMotocicleta.motocicleta(2019, 1000.2, "Nissan", 0.12);

            Console.WriteLine("Modelo: " + objMotocicleta.Modelo);
            Console.WriteLine("Precio: " + objMotocicleta.Precio);
            Console.WriteLine("Marca: " + objMotocicleta.Marca);
            Console.WriteLine("IVA: " + objMotocicleta.Iva);

            double precioiva = 1000.2 * 1.12;
            double pagoiva = precioiva - 1000.2;

            Console.WriteLine("El precio de la moto sin iva sería el mostrado anteriormente," + " pero con el IVA incluido el total sería de: Q" + precioiva);
            Console.WriteLine("Y el monto del IVA sería de: Q" + pagoiva);

            Console.ReadKey();
        }
    }
}
