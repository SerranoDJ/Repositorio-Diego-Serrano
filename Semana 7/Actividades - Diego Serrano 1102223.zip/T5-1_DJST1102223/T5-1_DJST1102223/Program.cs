﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace T5_1_DJST1102223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string moneda1 = "", moneda2="", moneda3=""; double cantidad1 = 0, cantidad2 = 0, cantidad3 = 0; 
            Console.WriteLine("TAREA 5, PROBLEMA 1");
            Console.WriteLine("Ingrese cantidad y su moneda");
            cantidad1 = Convert.ToDouble(Console.ReadLine());
            moneda1=Console.ReadLine();
            Console.WriteLine("Ingrese cantidad 2 y su moneda");
            cantidad2=Convert.ToDouble(Console.ReadLine());
            moneda2 = Console.ReadLine();
            Console.WriteLine("Ingrese cantidad 3 y su moneda");
            cantidad3=Convert.ToDouble(Console.ReadLine());
            moneda3= Console.ReadLine();

            if(cantidad1>0 && cantidad2>0 && cantidad3>0)
            {
                if (moneda1 == "USD" || moneda2=="USD" || moneda3=="USD")
                {
                    if(moneda1 == "USD")
                    {
                        cantidad1 = cantidad1 * 7.83;
                    }
                    else
                    {
                        cantidad1 = cantidad1;
                    }
                    if(moneda2 == "USD")
                    {
                        cantidad2 = cantidad2 * 7.83;
                    }
                    else
                    {
                        cantidad2 = cantidad2;
                    }
                    if (moneda3 == "USD")
                    {
                        cantidad3 = cantidad3 * 7.83;
                    }
                    else
                    {
                        cantidad3 = cantidad3;
                    }
                }
                if(cantidad1 > cantidad2 && cantidad1 > cantidad3 && cantidad2 > cantidad3) 
                {
                    Console.WriteLine("1. Q. " + cantidad1 + "2. Q. " + cantidad2 + "3. Q." + cantidad3);
                } else if (cantidad2>cantidad1 && cantidad2>cantidad3 && cantidad1 > cantidad3)
                {
                    Console.WriteLine("1. Q. " + cantidad2 + "2. Q." + cantidad1 + "3. Q. " + cantidad3);
                } else if(cantidad3>cantidad1 && cantidad3>cantidad2 && cantidad1 > cantidad2)
                {
                    Console.WriteLine("1. Q. " + cantidad3 + " 2. Q." + cantidad1 + " 3. Q. " + cantidad2);
                } else if((cantidad1>cantidad2) && (cantidad2 < cantidad3))
                {
                    Console.WriteLine("1. Q. " + cantidad1 + " 2. Q." + cantidad3 + " 3. Q. " + cantidad2);
                } else if ((cantidad1<cantidad2) && (cantidad1 > cantidad3))
                {
                    Console.WriteLine("1. Q. " + cantidad2 + " 2. Q." + cantidad1 + " 3. Q. " + cantidad3);
                } else if ((cantidad1<cantidad3) && (cantidad2 < cantidad1))
                {
                    Console.WriteLine("1. Q. " + cantidad2 + " 2. Q." + cantidad1 + " 3. Q. " + cantidad3);
                }
            }
            Console.ReadKey();
        }
    }
}
