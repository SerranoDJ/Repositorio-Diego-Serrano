﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_5_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero = 0; string num;
            Console.WriteLine("EJERCICIO 1");
            Console.WriteLine("Ingrese un número entero");
            num = Convert.ToString(Console.ReadLine());


            if (num != "") {

                numero = Convert.ToInt32(num);
                if (numero > 0)
                {
                    Console.WriteLine("el número es entero positivo");
                }
                else if (numero < 0) {

                    Console.WriteLine("el número es entero negativo");
                }
                else if (numero == 0) {

                    Console.WriteLine("el número es cero");
                }
            }
            else if (num=="") { Console.WriteLine("Error, valor inválido"); }
            Console.ReadKey();
        }
    }
}
