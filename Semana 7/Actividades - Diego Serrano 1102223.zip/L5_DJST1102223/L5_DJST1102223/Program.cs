﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_DJST1102223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero = 0;
            Console.WriteLine("EJERCICIO 2");
            Console.WriteLine("Ingrese el número de día,  entre 1 a 7");
            numero=Convert.ToInt32(Console.ReadLine());

            if(numero >0 && numero<8) { 
                if(numero==1) {
                    Console.WriteLine(numero + " lunes");
                } if(numero==2)
                {
                    Console.WriteLine(numero +" martes");
                } if (numero==3)
                {
                    Console.WriteLine(numero +" miércoles");
                }
                if (numero == 4){
                    Console.WriteLine( numero+ " jueves");
                }
                if (numero == 5)
                {
                    Console.WriteLine(numero +" viernes");
                }
                if (numero == 6)
                {
                    Console.WriteLine(numero + "sábado");
                }if (numero == 7)
                {
                    Console.WriteLine(numero +" domingo");
                }
            }
            else{ Console.WriteLine("día no válido"); }
            Console.ReadKey ();
        }
    }
}
