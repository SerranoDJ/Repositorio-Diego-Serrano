﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5._2_DJST1102223
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double precio = 0, desc=0, idesc=0; string sprecio = "",  codigo = "descuento";
            Console.WriteLine("Bienvenido a la tienda");
            Console.WriteLine("Ingrese el monto de su compra");
            sprecio=Console.ReadLine();

            precio = Convert.ToDouble(sprecio);
            if (sprecio=="")
            {
                Console.WriteLine("Error, no ingresó valor");
            }
            if (precio > 0) {

               if (precio > 400.00) {

                 if (precio <= 1000.00)
                    {
                        desc = precio * 0.07;
                        precio = precio - desc;
                        Console.WriteLine("Su precio con descuento será de: Q. " + precio);
                    }
                    else if (precio <= 1000.00)
                    {
                        desc = precio * 0.10;
                        precio = precio - desc;
                        Console.WriteLine("Su precio con descuento será de: Q. " + precio);
                    }
                    else if (precio <= 5000.00)
                    {
                        desc = precio * 0.15;
                        precio = precio - desc;
                        Console.WriteLine("Su precio con descuento será de: Q. " + precio);
                    }
                    else if (precio > 15000.00)
                    {
                        desc = precio * 0.25;
                        precio = precio - desc;
                        Console.WriteLine("Su precio con descuento será de: Q. " + precio);
                    }
                }
                else
                {
                    Console.WriteLine("No cuenta con descuento");
                }
            }
            Console.WriteLine("Ingrese código de descuento");
            codigo= Console.ReadLine();

            if (codigo=="descuento")
            {
                idesc = precio * 0.05;
                precio = precio - idesc;
                Console.WriteLine("Su precio con el código de descuento será de: " + precio);
            }
            else
            {
                Console.WriteLine("Código inválido");
            }
            Console.ReadKey();
        }
    }
}
